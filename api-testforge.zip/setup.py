from setuptools import setup, find_packages
setup(name='api-testforge',version='1.0.0',packages=find_packages(),
install_requires=['requests','pyyaml','click','jinja2'],
entry_points={'console_scripts':['apitestforge=apitestforge.cli:run']})
