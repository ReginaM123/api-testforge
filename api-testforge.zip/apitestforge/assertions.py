def assert_status(response, expected):
    return response.status_code == expected

def assert_json_value(response, path, expected):
    data=response.json()
    value=data
    for key in path.split('.'):
        value=value[key]
    return value==expected
