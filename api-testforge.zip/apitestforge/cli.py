import click
from .loader import load_test_file
from .runner import TestRunner
from .reports import generate_html_report, generate_json_report

@click.command()
@click.argument('testfile')
def run(testfile):
    tests=load_test_file(testfile)
    results=TestRunner().run(tests)
    for r in results:
        click.echo(f"{r['name']} : {r['status']}")
    generate_json_report(results,'reports/report.json')
    generate_html_report(results,'reports/report.html')

if __name__=='__main__':
    run()
