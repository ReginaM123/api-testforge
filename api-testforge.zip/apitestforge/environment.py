import os
def substitute_env(value):
    if isinstance(value,str):
        for k,v in os.environ.items():
            value=value.replace(f'${{{k}}}',v)
    return value
