import json
from datetime import datetime
def generate_json_report(results, filename):
    with open(filename,'w') as f:
        json.dump({'generated_at':str(datetime.now()),'results':results},f,indent=2)
def generate_html_report(results, filename):
    rows=''.join([f"<tr><td>{r['name']}</td><td>{r['status']}</td></tr>" for r in results])
    html=f"<html><body><h1>API Test Report</h1><table border='1'>{rows}</table></body></html>"
    open(filename,'w').write(html)
