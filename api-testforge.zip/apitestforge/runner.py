import requests
from .assertions import assert_status, assert_json_value
from .environment import substitute_env
class TestRunner:
    def run(self,test_cases):
        results=[]
        for test in test_cases:
            response=requests.request(
                test['request']['method'],
                substitute_env(test['request']['url']),
                json=test['request'].get('body',{}),
                headers=test['request'].get('headers',{})
            )
            passed=True
            for a in test['assertions']:
                if a['type']=='status_code':
                    passed &= assert_status(response,a['expected'])
                elif a['type']=='json_value':
                    passed &= assert_json_value(response,a['path'],a['expected'])
            results.append({'name':test['name'],'status':'PASSED' if passed else 'FAILED'})
        return results
